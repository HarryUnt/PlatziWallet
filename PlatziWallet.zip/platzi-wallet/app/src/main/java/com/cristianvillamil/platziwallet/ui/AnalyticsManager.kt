package com.cristianvillamil.platziwallet.ui

class AnalyticsManager {
    fun registerTransfer(token: String) {
        //registro la transferencia
    }
}