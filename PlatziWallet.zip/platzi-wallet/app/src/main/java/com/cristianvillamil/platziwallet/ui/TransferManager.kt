package com.cristianvillamil.platziwallet.ui

class TransferManager {
    fun transfer(token: String){
        //aqui se hace la transferencia
    }
}