package com.cristianvillamil.platziwallet.ui.transfer

interface OnItemSelected<T> {
    fun onItemSelected(item: T)
}