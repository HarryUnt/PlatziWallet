package com.cristianvillamil.platziwallet.ui

class SecurityManager {
    fun getToken() : String {
        return "laskjdlskjd82134kjsdLLKJ"
    }
}