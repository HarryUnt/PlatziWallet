package com.cristianvillamil.platziwallet.ui.home.view

data class UserViewModel (
    val userName: String,
    val photoURL: String
)